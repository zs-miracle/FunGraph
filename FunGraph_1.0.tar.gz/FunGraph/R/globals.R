utils::globalVariables(c("aes","clusterEvalQ","clusterExport","cv.glmnet",
                  "dmvnorm","facet_wrap","fpkm","gene","geom_line","ggplot","legendre.polynomials",
                  "makeCluster","melt","pbapply","pblapply","polynomial.derivatives",
                  "polynomial.values","scaleX","stopCluster","theme",'xlab',"ylab","detectCores"))